# Security Guidelines

- Use IAM roles instead of long-lived access keys.
- Do not commit `.env` files or credentials.
- Run in a dedicated test account first.
- Review generated findings before enabling remediation.
- Log all remediation activity in CloudTrail/CloudWatch.
- Use change control for RDS/EBS migration work.
- Do not automatically delete GuardDuty evidence.
- Restrict the automation role to only the AWS APIs required by the enabled playbooks.
