# AWS Cloud Security Auto-Remediation Framework

A defensive, least-privilege AWS security automation project built with **Python + Boto3**.

## What it detects

- Public S3 buckets
- Security groups exposing SSH (22) or RDP (3389) to `0.0.0.0/0`
- IAM users with old access keys and wildcard (`*`) identity policies
- High-severity GuardDuty findings
- Unencrypted EBS volumes
- Unencrypted RDS instances

## What it remediates

Remediation is **disabled by default**.

When explicitly enabled, the framework can:

- Block public S3 access and add a restrictive bucket policy
- Remove unrestricted SSH/RDP ingress rules
- Disable old IAM access keys
- Tag or isolate high-risk resources where supported by the selected playbook
- Report GuardDuty findings without deleting evidence
- Snapshot/replace resources is intentionally NOT automated; destructive database/storage changes require human approval

## Architecture

```text
EventBridge / Scheduler
        |
        v
 Python Security Scanner
        |
        +--> S3 public access
        +--> EC2 Security Groups
        +--> IAM
        +--> GuardDuty
        +--> EBS / RDS encryption
        |
        v
 Findings JSON
        |
        +--> Remediation Engine (optional)
        |
        v
 Markdown + JSON Security Report
        |
        v
 CloudWatch / SNS / SIEM (optional extension)
```

## Requirements

- Python 3.11+
- AWS account for integration testing
- Boto3
- AWS credentials configured through an IAM role/profile
- Never commit AWS keys to Git

Install:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Windows:

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

## Configuration

Copy `.env.example` to `.env` if you use environment variables:

```text
AWS_REGION=us-east-1
REMEDIATION_ENABLED=false
REPORT_DIR=reports
IAM_KEY_MAX_AGE_DAYS=90
```

The sample project deliberately defaults to **dry-run**.

## Run a security scan

```bash
python -m src.main
```

Run with remediation explicitly enabled:

```bash
REMEDIATION_ENABLED=true python -m src.main
```

PowerShell:

```powershell
$env:REMEDIATION_ENABLED="true"
python -m src.main
```

## IAM permissions

Start with read-only permissions for scanning. Add remediation permissions only after reviewing the code and testing in a non-production AWS account.

Typical read permissions include:

- `s3:GetBucketAcl`
- `s3:GetBucketPolicy`
- `s3:GetBucketPublicAccessBlock`
- `ec2:DescribeSecurityGroups`
- `ec2:DescribeVolumes`
- `rds:DescribeDBInstances`
- `iam:ListUsers`
- `iam:ListAccessKeys`
- `iam:ListUserPolicies`
- `iam:GetUserPolicy`
- `guardduty:ListDetectors`
- `guardduty:ListFindings`
- `guardduty:GetFindings`

Potential remediation permissions include:

- `s3:PutPublicAccessBlock`
- `s3:PutBucketPolicy`
- `ec2:RevokeSecurityGroupIngress`
- `iam:UpdateAccessKey`

Use a dedicated automation role and scope permissions to the resources/accounts where possible.

## Security design

1. **Dry-run by default**
2. **Least privilege**
3. **Idempotent remediation**
4. **Audit every action**
5. **Never delete GuardDuty findings automatically**
6. **Do not automatically destroy or replace databases/volumes**
7. **Use CloudTrail to preserve an audit trail**
8. **Test in a sandbox account before production**

## Example output

```text
AWS CLOUD SECURITY REPORT
Generated: 2026-09-18T...
Findings: 7
Critical: 1
High: 3
Medium: 2
Low: 1

[HIGH] S3 bucket allows public access
[HIGH] Security group allows SSH from 0.0.0.0/0
[HIGH] EBS volume is not encrypted
...
```

## Portfolio extensions

For a stronger production-style portfolio project, add:

- EventBridge-triggered Lambda
- SNS/Slack notifications
- AWS Security Hub integration
- CloudWatch metrics
- DynamoDB remediation history
- Terraform deployment
- GitHub Actions CI/CD
- Bandit, Ruff, pytest and Trivy
- CIS AWS Foundations benchmark mapping
- Multi-account AWS Organizations support
- Approval workflow for high-impact remediation

## Important

This project is intended for authorized AWS environments. Review every remediation rule against your organization's change-management requirements before enabling it.
